export class Customer{
    Customer_id:Number;
    firstName:string;
    lastName:string;
    customerPnone:string;
    userid:number;
    
}