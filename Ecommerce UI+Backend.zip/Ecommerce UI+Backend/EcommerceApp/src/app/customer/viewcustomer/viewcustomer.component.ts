import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewcustomer',
  templateUrl: './viewcustomer.component.html',
  styleUrls: ['./viewcustomer.component.css']
})
export class ViewcustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
