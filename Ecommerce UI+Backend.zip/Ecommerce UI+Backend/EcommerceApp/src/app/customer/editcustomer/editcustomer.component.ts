import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editcustomer',
  templateUrl: './editcustomer.component.html',
  styleUrls: ['./editcustomer.component.css']
})
export class EditcustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
