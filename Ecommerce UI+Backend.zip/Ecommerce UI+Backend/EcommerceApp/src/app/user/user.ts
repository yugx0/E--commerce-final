export class User{
    user_id:number;
    emailid:string;
    password:string;
    enabled:string;

}