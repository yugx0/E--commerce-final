export class Product {

    product_id:number;
    category: string;
    description: string;
    manufacturer: string;
    name: string;
    price: string;
    unit:string;
}
